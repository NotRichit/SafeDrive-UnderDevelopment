const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const session = require('express-session');
const path = require('path');

const userController = require('./controllers/userController');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }  // Set to true if using https
}));

app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

const storage = multer.memoryStorage();
const upload = multer({ storage: storage, limits: { fileSize: 500 * 1024 * 1024 } });

app.get('/user-files', (req, res) => {
    const userDir = path.join(__dirname, 'users', req.session.username);

    // Read the contents of the user's directory
    fs.readdir(userDir, (err, files) => {
        if (err) {
            console.error('Error reading user directory:', err);
            return res.status(500).send('Error reading user directory');
        }

        // Pass the list of files to the template engine for rendering
        res.render('user-files', { files });
    });
});
app.get('/', userController.renderHome);
app.get('/register', userController.renderRegister);
app.post('/register', userController.register);
app.get('/login', userController.renderLogin);
app.post('/login', userController.login);
app.get('/2fa-setup', userController.render2FASetup);
app.post('/2fa-setup', userController.setup2FA);
app.get('/2fa-verify', userController.isAuthenticated, userController.render2FAVerify);
app.post('/2fa-verify', userController.isAuthenticated, userController.verify2FA);
app.get('/upload', userController.isAuthenticated, userController.renderUpload);
app.post('/upload', userController.isAuthenticated, upload.single('file'), userController.uploadFile);
app.get('/download', userController.isAuthenticated, userController.downloadFile);
app.get('/list-files', userController.isAuthenticated, userController.listFiles);
app.post('/delete-file', userController.isAuthenticated, userController.deleteFile);
// Admin route
app.get('/admin', userController.renderAdmin);
app.post('/admin-login', userController.adminLogin);

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});