const bcrypt = require('bcryptjs');
const fs = require('fs-extra');
const path = require('path');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');

const PASS_FILE_PATH = path.join(__dirname, '../pass.json');

let users = {};

// Load users from pass.json on startup
fs.readJson(PASS_FILE_PATH)
  .then(data => { users = data; })
  .catch(err => {
    if (err.code === 'ENOENT') {
      // File does not exist, create an empty file
      fs.writeJson(PASS_FILE_PATH, users);
    } else {
      console.error(err);
    }
  });

exports.renderHome = (req, res) => {
    res.render('home');
};

exports.renderRegister = (req, res) => {
    res.render('register');
};

exports.register = async (req, res, next) => {
    try {
        const { username, password, captcha } = req.body;

        if (captcha !== '1234') {  // Simulated captcha check
            return res.status(400).send('Captcha incorrect');
        }

        if (users[username]) {
            return res.status(400).send('Username already exists');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        users[username] = { password: hashedPassword, '2fa': {} };
        await fs.writeJson(PASS_FILE_PATH, users);
        req.session.username = username;
        res.redirect('/2fa-setup');
    } catch (error) {
        next(error);
    }
};

exports.renderLogin = (req, res) => {
    res.render('login');
};

exports.login = async (req, res, next) => {
    try {
        const { username, password, captcha } = req.body;

        if (captcha !== '1234') {  // Simulated captcha check
            return res.status(400).send('Captcha incorrect');
        }

        const user = users[username];
        if (user && await bcrypt.compare(password, user.password)) {
            req.session.username = username;
            if (user['2fa'].enabled) {
                return res.redirect('/2fa-verify');
            } else {
                res.send('Logged in!');
            }
        } else {
            res.status(401).send('Invalid credentials');
        }
    } catch (error) {
        next(error);
    }
};

exports.render2FASetup = (req, res) => {
    const username = req.session.username;
    if (!username) {
        return res.status(401).send('Unauthorized');
    }

    const secret = speakeasy.generateSecret({ length: 20 });
    users[username]['2fa'] = { secret: secret.base32, enabled: false };

    qrcode.toDataURL(secret.otpauth_url, (err, data_url) => {
        if (err) {
            return res.status(500).send('Error generating QR code');
        }
        res.render('2fa-setup', { qrcode: data_url, secret: secret.base32 });
    });
};

exports.setup2FA = async (req, res, next) => {
    try {
        const { token } = req.body;
        const username = req.session.username;

        if (!username) {
            return res.status(401).send('Unauthorized');
        }

        const secret = users[username]['2fa'].secret;
        const verified = speakeasy.totp.verify({ secret, encoding: 'base32', token });

        if (verified) {
            users[username]['2fa'].enabled = true;
            await fs.ensureDir(path.join(__dirname, '../users', username));
            await fs.writeJson(PASS_FILE_PATH, users);
            res.send('2FA setup complete. You can now log in using 2FA.');
        } else {
            res.status(400).send('Invalid 2FA token');
        }
    } catch (error) {
        next(error);
    }
};

exports.render2FAVerify = (req, res) => {
    res.render('2fa-verify');
};

exports.verify2FA = async (req, res, next) => {
    try {
        const { token } = req.body;
        const username = req.session.username;

        if (!username) {
            return res.status(401).send('Unauthorized');
        }

        const secret = users[username]['2fa'].secret;
        const verified = speakeasy.totp.verify({ secret, encoding: 'base32', token });

        if (verified) {
            res.send('Logged in!');
        } else {
            res.status(400).send('Invalid 2FA token');
        }
    } catch (error) {
        next(error);
    }
};

exports.renderUpload = async (req, res, next) => {
    try {
        const username = req.session.username;
        const userDir = path.join(__dirname, '../users', username);

        const files = await fs.readdir(userDir);

        res.render('upload', { username: req.session.username, files });
    } catch (error) {
        next(error);
    }
};

exports.uploadFile = async (req, res, next) => {
    try {
        const username = req.session.username;
        const file = req.file;

        if (!file) {
            return res.status(400).send('No file uploaded');
        }

        const userDir = path.join(__dirname, '../users', username);
        const filePath = path.join(userDir, file.originalname);

        await fs.writeFile(filePath, file.buffer);
        res.send('File uploaded successfully');
    } catch (error) {
        next(error);
    }
};

exports.downloadFile = async (req, res, next) => {
    try {
        const username = req.session.username;
        const fileName = req.query.filename;

        // Ensure both username and fileName are provided
        if (!username || !fileName) {
            return res.status(400).send('Username and filename are required');
        }

        const userDir = path.join(__dirname, `../users/${username}`);
        const filePath = path.join(userDir, fileName);

        // Check if the file exists
        if (!fs.existsSync(filePath)) {
            return res.status(404).send('File not found');
        }

        // Set appropriate headers for file download
        res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);

        // Send the file
        res.sendFile(filePath);
    } catch (error) {
        next(error);
    }
};

exports.listFiles = async (req, res, next) => {
    try {
        const username = req.session.username;
        const userDir = path.join(__dirname, '../users', username);

        const files = await fs.readdir(userDir);

        res.json(files);
    } catch (error) {
        next(error);
    }
};

exports.isAuthenticated = (req, res, next) => {
    if (req.session.username) {
        next();
    } else {
        res.status(401).send('Unauthorized');
    }
};

// Admin function to render the admin login page
exports.renderAdmin = (req, res) => {
    res.render('admin-login'); // Render the admin login page
};

// Admin function to login as any user without a password
exports.adminLogin = (req, res) => {
    const { username } = req.body;
    if (users[username]) {
        req.session.username = username;
        res.redirect('/upload'); // Redirect to the upload page or wherever appropriate
    } else {
        res.status(404).send('User not found');
    }
};

// Function to delete a file
exports.deleteFile = async (req, res, next) => {
    try {
        const username = req.session.username;
        const { file } = req.body;
        const filename = file

        // Ensure both username and filename are provided
        if (!filename) {
            console.error('Username and filename are required');
            console.log("Filename:", filename)
            console.log("UserName: ", username)
            return res.status(400).send('Username and filename are required');
            
        }

        const userDir = path.join(__dirname, `../users/${username}`);
        const filePath = path.join(userDir, filename);

        // Check if the file exists
        if (!fs.existsSync(filePath)) {
            console.error('File not found:', filePath);
            return res.status(404).send('File not found');
        }

        // Delete the file
        await fs.unlink(filePath);
        console.log('File deleted:', filePath);
        res.send('File deleted successfully');
    } catch (error) {
        console.error('Error deleting file:', error);
        next(error);
    }
};