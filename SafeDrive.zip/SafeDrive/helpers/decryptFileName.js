// decryptFileName.js

const crypto = require('crypto');

// Define encryption parameters
const algorithm = 'aes-256-cbc';
const key = Buffer.from('tzK66pArN36nqPZCzjUAk79ijZxlsINd', 'hex'); // Replace with your encryption key
const iv = Buffer.from('7fb62806599fd2661401da176cb9f7d8', 'hex'); // Replace with your initialization vector

const decryptFileName = (encryptedFileName) => {
    try {
        // Decrypt the filename
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        let decryptedFileName = decipher.update(encryptedFileName, 'hex', 'utf-8');
        decryptedFileName += decipher.final('utf-8');
        
        return decryptedFileName;
    } catch (error) {
        // Log decryption error
        console.error('Error decrypting filename:', error);
        throw new Error('Decryption failed: ' + error.message);
    }
};

module.exports = decryptFileName;