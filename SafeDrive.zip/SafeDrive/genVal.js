const crypto = require('crypto');
const secret = 'richit'
// Generate a random encryption key
const encryptionKey = crypto.randomBytes(32).toString('hex'); // 32 bytes for AES-256

// Generate a random IV
const iv = crypto.randomBytes(16); // 16 bytes for AES-256 in CBC mode
// Generate a random encryption key
const encryptionKeey = crypto.randomBytes(32).toString('hex'); // 32 bytes for AES-256
let key = crypto.createHash('sha256').update(String(secret)).digest('base64').substr(0, 32)
console.log('Encryption Key:', encryptionKeey);
console.log('Encryption Key:', encryptionKey)
console.log('Nee Meg: ', key)
console.log('Initialization Vector (IV):', iv.toString('hex'));
